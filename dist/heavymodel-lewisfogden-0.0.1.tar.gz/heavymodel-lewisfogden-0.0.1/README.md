# heavymodel

heavymodel is a class-based library which enables Actuaries (and other modelling professionals) to build actuarial models in Python, using a function-based syntax similar to other actuarial modelling software, combined with the simplicity of writing code in python.
